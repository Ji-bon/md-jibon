# All-Package-auto-install
In this i have build all main tools in one script only one time run this script it will automatically install all important package..

For run the script type


1) pkg install git


2)git clone https://github.com/bokxud/All_package


1)cd All_package


2)sh TOOLS.sh


it will automatically install all the package.
enjoy 👍


contact and flow me😎😎



Youtube : https://youtube.com/c/BDKR-28


Telegram : https://t.me/BDKR28

